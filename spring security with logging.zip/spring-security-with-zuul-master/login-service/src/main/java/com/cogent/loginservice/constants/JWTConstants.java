package com.cogent.loginservice.constants;

public class JWTConstants {

    public static final String JWT_SECRET_KEY = "QnuQblQWn8H9ggiwfGbCxpPA3gdY1oAe";
    public static final String JWT_KEY = "QnuQblQWn8H9ggiwfGbCxpPA3gdY1oAe";
}
